# jsNSRecruit
Recruiter for Nationstates written in node.js

## Setup
1. Download **all** the files, or clone the repo to your local PC.
2. Run `npm install` in a command line opened in the folder, which will install all dependencies.
3. Replace all info in the `config.json` with your own info.
4. Run the program in the command line with `node index.js`.

## Contributing
1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request!

## Author
**ModzBot** © [ModzOn](https://github.com/ModzOnYT), Released under the [MIT](https://github.com/ModzOnYT/jsNSRecruit/blob/master/LICENSE) License.<br>
Authored and maintained by ModzOn.

> GitHub [@ModzOn](https://github.com/ModzOn)
